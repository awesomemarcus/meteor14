var require = meteorInstall({"lib":{"collections":{"categories.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// lib/collections/categories.js                                                                     //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
exports.__esModule = true;                                                                           //
                                                                                                     //
var _mongo = require('meteor/mongo');                                                                // 1
                                                                                                     //
var Categories = new _mongo.Mongo.Collection('categories');                                          // 4
                                                                                                     //
exports['default'] = Categories;                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./categories","./products",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// lib/collections/index.js                                                                          //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
exports.__esModule = true;                                                                           //
exports.Products = exports.Categories = exports.undefined = undefined;                               //
                                                                                                     //
var _categories = require('./categories');                                                           // 1
                                                                                                     //
var _categories2 = _interopRequireDefault(_categories);                                              //
                                                                                                     //
var _products = require('./products');                                                               // 2
                                                                                                     //
var _products2 = _interopRequireDefault(_products);                                                  //
                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }    //
                                                                                                     //
exports.undefined = undefined;                                                                       //
exports.Categories = _categories2['default'];                                                        //
exports.Products = _products2['default'];                                                            //
///////////////////////////////////////////////////////////////////////////////////////////////////////

}],"products.js":["meteor/mongo","meteor/aldeed:simple-schema",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// lib/collections/products.js                                                                       //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
exports.__esModule = true;                                                                           //
exports.ProductSchem = undefined;                                                                    //
                                                                                                     //
var _mongo = require('meteor/mongo');                                                                // 1
                                                                                                     //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                    // 2
                                                                                                     //
var Products = new _mongo.Mongo.Collection('products');                                              // 4
                                                                                                     //
var ProductSchem = exports.ProductSchem = new _aldeedSimpleSchema.SimpleSchema({                     // 6
  category_id: {                                                                                     // 7
    type: String,                                                                                    // 8
    label: 'Category ID'                                                                             // 9
  },                                                                                                 //
  name: {                                                                                            // 11
    type: String,                                                                                    // 12
    label: 'Name',                                                                                   // 13
    max: 10,                                                                                         // 14
    min: 3                                                                                           // 15
  },                                                                                                 //
  description: {                                                                                     // 17
    type: String,                                                                                    // 18
    label: 'Description',                                                                            // 19
    max: 300,                                                                                        // 20
    min: 10                                                                                          // 21
  },                                                                                                 //
  price: {                                                                                           // 23
    type: Number,                                                                                    // 24
    decimal: true,                                                                                   // 25
    label: 'Price'                                                                                   // 26
  },                                                                                                 //
  createdAt: {                                                                                       // 28
    type: Date,                                                                                      // 29
    label: 'Created At',                                                                             // 30
    optional: true                                                                                   // 31
  },                                                                                                 //
  modifiedAt: {                                                                                      // 33
    type: Date,                                                                                      // 34
    label: 'Modified At',                                                                            // 35
    optional: true                                                                                   // 36
  },                                                                                                 //
  isDeleted: {                                                                                       // 38
    type: Boolean,                                                                                   // 39
    label: 'Deleted',                                                                                // 40
    optional: true                                                                                   // 41
  }                                                                                                  //
});                                                                                                  //
                                                                                                     //
exports['default'] = Products;                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////

}],"users.js":["meteor/aldeed:simple-schema",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// lib/collections/users.js                                                                          //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
exports.__esModule = true;                                                                           //
                                                                                                     //
var _aldeedSimpleSchema = require("meteor/aldeed:simple-schema");                                    // 1
                                                                                                     //
/**                                                                                                  //
 * Users schema                                                                                      //
 */                                                                                                  //
                                                                                                     //
_aldeedSimpleSchema.SimpleSchema.messages({                                                          // 8
  regEx: [{ msg: "[label] must be valid." }]                                                         // 9
});                                                                                                  //
var UsersSchema = new _aldeedSimpleSchema.SimpleSchema({                                             // 11
                                                                                                     //
  profile: {                                                                                         // 13
    type: Object,                                                                                    // 14
    optional: true,                                                                                  // 15
    label: "Porfile"                                                                                 // 16
  },                                                                                                 //
                                                                                                     //
  "profile.username": {                                                                              // 19
    type: String,                                                                                    // 20
    min: 1,                                                                                          // 21
    label: "Username"                                                                                // 22
  },                                                                                                 //
                                                                                                     //
  "profile.firstname": {                                                                             // 25
    type: String,                                                                                    // 26
    label: "Firstname",                                                                              // 27
    min: 1                                                                                           // 28
  },                                                                                                 //
                                                                                                     //
  "profile.lastname": {                                                                              // 31
    type: String,                                                                                    // 32
    min: 1,                                                                                          // 33
    label: "Lastname"                                                                                // 34
  },                                                                                                 //
                                                                                                     //
  "profile.gender": {                                                                                // 37
    type: String,                                                                                    // 38
    allowedValues: ["male", "female"],                                                               // 39
    label: "Gender"                                                                                  // 40
  },                                                                                                 //
                                                                                                     //
  "profile.age": {                                                                                   // 43
    type: Number,                                                                                    // 44
    label: "Age",                                                                                    // 45
    min: 18,                                                                                         // 46
    max: 99                                                                                          // 47
  },                                                                                                 //
                                                                                                     //
  services: {                                                                                        // 50
    type: Object,                                                                                    // 51
    optional: true,                                                                                  // 52
    blackbox: true                                                                                   // 53
  },                                                                                                 //
                                                                                                     //
  emails: {                                                                                          // 56
    type: Array,                                                                                     // 57
    optional: true,                                                                                  // 58
    label: "Email"                                                                                   // 59
  },                                                                                                 //
                                                                                                     //
  "emails.$": {                                                                                      // 62
    type: Object                                                                                     // 63
  },                                                                                                 //
                                                                                                     //
  "emails.$.address": {                                                                              // 66
    label: "Email Addess",                                                                           // 67
    type: String,                                                                                    // 68
    regEx: _aldeedSimpleSchema.SimpleSchema.RegEx.Email                                              // 69
  },                                                                                                 //
                                                                                                     //
  "emails.$.verified": {                                                                             // 72
    type: Boolean                                                                                    // 73
  },                                                                                                 //
                                                                                                     //
  password: {                                                                                        // 76
    type: String,                                                                                    // 77
    label: "Password",                                                                               // 78
    min: 6,                                                                                          // 79
    max: 20                                                                                          // 80
  },                                                                                                 //
                                                                                                     //
  modifiedAt: {                                                                                      // 83
    type: Date,                                                                                      // 84
    label: "ModifiedAt",                                                                             // 85
    defaultValue: new Date()                                                                         // 86
  },                                                                                                 //
                                                                                                     //
  createdAt: {                                                                                       // 89
    type: Date,                                                                                      // 90
    label: "CreatedAt",                                                                              // 91
    defaultValue: new Date()                                                                         // 92
  }                                                                                                  //
                                                                                                     //
});                                                                                                  //
                                                                                                     //
exports["default"] = UsersSchema;                                                                    //
///////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"methods":{"categories.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// server/methods/categories.js                                                                      //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
exports.__esModule = true;                                                                           //
                                                                                                     //
exports['default'] = function () {                                                                   //
  _meteor.Meteor.methods({                                                                           // 6
    'categoriesAdd': function () {                                                                   // 7
      function categoriesAdd(data) {                                                                 //
        (0, _check.check)(data, Object);                                                             // 8
        _collections.Categories.insert({                                                             // 9
          name: data.name,                                                                           // 10
          modifiedAt: new Date(),                                                                    // 11
          createdAt: new Date()                                                                      // 12
        });                                                                                          //
      }                                                                                              //
                                                                                                     //
      return categoriesAdd;                                                                          //
    }(),                                                                                             //
    'categoriesUpdate': function () {                                                                // 15
      function categoriesUpdate(data) {                                                              //
        (0, _check.check)(data, Object);                                                             // 16
        _collections.Categories.update({ _id: data._id }, { $set: {                                  // 17
            name: data.name,                                                                         // 18
            modifiedAt: new Date(),                                                                  // 19
            createdAt: new Date()                                                                    // 20
          } });                                                                                      //
      }                                                                                              //
                                                                                                     //
      return categoriesUpdate;                                                                       //
    }()                                                                                              //
  });                                                                                                //
};                                                                                                   //
                                                                                                     //
var _collections = require('/lib/collections');                                                      // 1
                                                                                                     //
var _meteor = require('meteor/meteor');                                                              // 2
                                                                                                     //
var _check = require('meteor/check');                                                                // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./products","./categories","./users",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// server/methods/index.js                                                                           //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
exports.__esModule = true;                                                                           //
                                                                                                     //
exports['default'] = function () {                                                                   //
  (0, _products2['default'])();                                                                      // 6
  (0, _categories2['default'])();                                                                    // 7
  (0, _users2['default'])();                                                                         // 8
};                                                                                                   //
                                                                                                     //
var _products = require('./products');                                                               // 1
                                                                                                     //
var _products2 = _interopRequireDefault(_products);                                                  //
                                                                                                     //
var _categories = require('./categories');                                                           // 2
                                                                                                     //
var _categories2 = _interopRequireDefault(_categories);                                              //
                                                                                                     //
var _users = require('./users');                                                                     // 3
                                                                                                     //
var _users2 = _interopRequireDefault(_users);                                                        //
                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }    //
///////////////////////////////////////////////////////////////////////////////////////////////////////

}],"products.js":["/lib/collections/products.js","meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// server/methods/products.js                                                                        //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
exports.__esModule = true;                                                                           //
                                                                                                     //
exports['default'] = function () {                                                                   //
  _meteor.Meteor.methods({                                                                           // 6
    'insertProduct': function () {                                                                   // 7
      function insertProduct(category_id, name, description, price) {                                //
        var createdAt = new Date();                                                                  // 8
                                                                                                     //
        (0, _check.check)(category_id, String);                                                      // 10
        (0, _check.check)(name, String);                                                             // 11
        (0, _check.check)(description, String);                                                      // 12
        (0, _check.check)(price, String);                                                            // 13
        (0, _check.check)(createdAt, Date);                                                          // 14
                                                                                                     //
        var formDate = {                                                                             // 16
          category_id: category_id,                                                                  // 17
          name: name,                                                                                // 18
          description: description,                                                                  // 19
          price: Number(price)                                                                       // 20
        };                                                                                           //
                                                                                                     //
        var isValid = _products.ProductSchem.namedContext("myContext").validate(formDate);           // 23
        if (isValid === true) {                                                                      // 24
          var prodDetails = {                                                                        // 25
            category_id: category_id,                                                                // 26
            name: name,                                                                              // 27
            description: description,                                                                // 28
            price: price,                                                                            // 29
            createdAt: createdAt,                                                                    // 30
            modifiedAt: null,                                                                        // 31
            deleted: null,                                                                           // 32
            saving: true                                                                             // 33
          };                                                                                         //
          _products2['default'].insert(prodDetails);                                                 // 35
        }                                                                                            //
                                                                                                     //
        // check(categoryid, String);                                                                //
        // check(name, String);                                                                      //
        // check(description, String);                                                               //
        // check(price, String);                                                                     //
        // check(createdAt, Date);                                                                   //
                                                                                                     //
        // const prodDetails = {                                                                     //
        //   categoryid,                                                                             //
        //   name,                                                                                   //
        //   description,                                                                            //
        //   price,                                                                                  //
        //   createdAt,                                                                              //
        //   modifiedAt: null,                                                                       //
        //   deleted: null,                                                                          //
        //   saving: true,                                                                           //
        // };                                                                                        //
        // Products.insert(prodDetails);                                                             //
      }                                                                                              // 7
                                                                                                     //
      return insertProduct;                                                                          //
    }(),                                                                                             //
    'deleteProduct': function () {                                                                   // 57
      function deleteProduct(id) {                                                                   //
        (0, _check.check)(id, String);                                                               // 58
        _products2['default'].update({ _id: id }, { $set: { deleted: true } });                      // 59
      }                                                                                              //
                                                                                                     //
      return deleteProduct;                                                                          //
    }(),                                                                                             //
    'updateProduct': function () {                                                                   // 62
      function updateProduct(id, categoryid, name, description, price) {                             //
        (0, _check.check)(id, String);                                                               // 63
        (0, _check.check)(categoryid, String);                                                       // 64
        (0, _check.check)(name, String);                                                             // 65
        (0, _check.check)(description, String);                                                      // 66
        (0, _check.check)(price, Number);                                                            // 67
        _products2['default'].update({ _id: id }, { $set: { category_id: categoryid, name: name, description: description, price: price, modifiedAt: new Date() } });
      }                                                                                              //
                                                                                                     //
      return updateProduct;                                                                          //
    }()                                                                                              //
  });                                                                                                //
};                                                                                                   //
                                                                                                     //
var _products = require('/lib/collections/products.js');                                             // 1
                                                                                                     //
var _products2 = _interopRequireDefault(_products);                                                  //
                                                                                                     //
var _meteor = require('meteor/meteor');                                                              // 2
                                                                                                     //
var _check = require('meteor/check');                                                                // 3
                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }    //
///////////////////////////////////////////////////////////////////////////////////////////////////////

}],"users.js":["/lib/collections/users.js","meteor/meteor","meteor/check","meteor/accounts-base",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// server/methods/users.js                                                                           //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
exports.__esModule = true;                                                                           //
                                                                                                     //
exports['default'] = function () {                                                                   //
  _meteor.Meteor.methods({                                                                           // 26
    'usersLogin': function () {                                                                      // 27
      function usersLogin(formData) {                                                                //
        (0, _check.check)(formData, Object);                                                         // 28
        // let isValid = UsersSchema.namedContext("myContext").validate(formData,"email.$.address");
        // let isValid2 = UsersSchema.namedContext("myContext").validateOne(formData,"password");    //
        // check(formData,UsersSchema,(err)=>{                                                       //
        //                                                                                           //
        // });                                                                                       //
      }                                                                                              //
                                                                                                     // 27
      return usersLogin;                                                                             //
    }(),                                                                                             //
    'usersSignup': function () {                                                                     // 36
      function usersSignup(formData) {                                                               //
        (0, _check.check)(formData, Object);                                                         // 37
        var Checker = _users2['default'].namedContext("myContext");                                  // 38
        var schemaNoError = Checker.validate(formData);                                              // 39
                                                                                                     //
        if (!schemaNoError) {                                                                        // 41
          throw new Error("Please fill in the form correctly.");                                     // 42
        }                                                                                            //
        _accountsBase.Accounts.createUser({                                                          // 44
          "email": formData["emails.$.address"],                                                     // 45
          "password": formData["password"],                                                          // 46
          "profile.username": formData["profile.username"],                                          // 47
          "profile.firstname": formData["profile.firstname"],                                        // 48
          "profile.lastname": formData["profile.lastname"],                                          // 49
          "profile.gender": formData["profile.gender"],                                              // 50
          "profile.age": formData["profile.age"],                                                    // 51
          modifiedAt: new Date(),                                                                    // 52
          createdAt: new Date()                                                                      // 53
        });                                                                                          //
      }                                                                                              //
                                                                                                     //
      return usersSignup;                                                                            //
    }()                                                                                              //
  });                                                                                                //
};                                                                                                   //
                                                                                                     //
var _users = require('/lib/collections/users.js');                                                   // 1
                                                                                                     //
var _users2 = _interopRequireDefault(_users);                                                        //
                                                                                                     //
var _meteor = require('meteor/meteor');                                                              // 2
                                                                                                     //
var _check = require('meteor/check');                                                                // 3
                                                                                                     //
var _accountsBase = require('meteor/accounts-base');                                                 // 4
                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }    //
                                                                                                     //
_meteor.Meteor.startup(function () {                                                                 // 6
  _accountsBase.Accounts.config({                                                                    // 7
    forbidClientAccountCreation: true                                                                // 8
  });                                                                                                //
  _accountsBase.Accounts.onCreateUser(function (options, user) {                                     // 10
    user.profile = {};                                                                               // 11
    user.profile.username = options["profile.username"];                                             // 12
    user.profile.firstname = options["profile.firstname"];                                           // 13
    user.profile.lastname = options["profile.lastname"];                                             // 14
    user.profile.gender = options["profile.gender"];                                                 // 15
    user.profile.age = options["profile.age"];                                                       // 16
    user.modifiedAt = options["modifiedAt"];                                                         // 17
    user.createdAt = options["createdAt"];                                                           // 18
    return user;                                                                                     // 19
  });                                                                                                //
});                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"publications":{"categories.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// server/publications/categories.js                                                                 //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
exports.__esModule = true;                                                                           //
                                                                                                     //
exports['default'] = function () {                                                                   //
                                                                                                     //
  _meteor.Meteor.publish('categoriesList', function () {                                             // 7
                                                                                                     //
    return [_collections.Categories.find(), _collections.Products.find()];                           // 9
  });                                                                                                //
                                                                                                     //
  _meteor.Meteor.publish('categoriesSingle', function (category_id) {                                // 16
                                                                                                     //
    (0, _check.check)(category_id, String);                                                          // 18
                                                                                                     //
    return _collections.Categories.find({ _id: category_id });                                       // 20
  });                                                                                                //
};                                                                                                   //
                                                                                                     //
var _collections = require('/lib/collections');                                                      // 1
                                                                                                     //
var _meteor = require('meteor/meteor');                                                              // 2
                                                                                                     //
var _check = require('meteor/check');                                                                // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./categories","./users","./products",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// server/publications/index.js                                                                      //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
exports.__esModule = true;                                                                           //
                                                                                                     //
exports['default'] = function () {                                                                   //
  (0, _categories2['default'])();                                                                    // 6
  (0, _users2['default'])();                                                                         // 7
  (0, _products2['default'])();                                                                      // 8
};                                                                                                   //
                                                                                                     //
var _categories = require('./categories');                                                           // 1
                                                                                                     //
var _categories2 = _interopRequireDefault(_categories);                                              //
                                                                                                     //
var _users = require('./users');                                                                     // 2
                                                                                                     //
var _users2 = _interopRequireDefault(_users);                                                        //
                                                                                                     //
var _products = require('./products');                                                               // 3
                                                                                                     //
var _products2 = _interopRequireDefault(_products);                                                  //
                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }    //
///////////////////////////////////////////////////////////////////////////////////////////////////////

}],"products.js":["meteor/meteor","/lib/collections",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// server/publications/products.js                                                                   //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
exports.__esModule = true;                                                                           //
                                                                                                     //
exports['default'] = function () {                                                                   //
                                                                                                     //
  _meteor.Meteor.publish('productList', function () {                                                // 6
    return [_collections.Products.find(), _collections.Categories.find()];                           // 7
  });                                                                                                //
};                                                                                                   //
                                                                                                     //
var _meteor = require('meteor/meteor');                                                              // 1
                                                                                                     //
var _collections = require('/lib/collections');                                                      // 2
///////////////////////////////////////////////////////////////////////////////////////////////////////

}],"users.js":["meteor/meteor",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// server/publications/users.js                                                                      //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
exports.__esModule = true;                                                                           //
                                                                                                     //
exports['default'] = function () {                                                                   //
  _meteor.Meteor.publish('users.current', function () {                                              // 5
    return _meteor.Meteor.users.find(this.userId);                                                   // 6
  });                                                                                                //
};                                                                                                   //
                                                                                                     //
var _meteor = require('meteor/meteor');                                                              // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"main.js":["./publications","./methods",function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// server/main.js                                                                                    //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
var _publications = require('./publications');                                                       // 1
                                                                                                     //
var _publications2 = _interopRequireDefault(_publications);                                          //
                                                                                                     //
var _methods = require('./methods');                                                                 // 2
                                                                                                     //
var _methods2 = _interopRequireDefault(_methods);                                                    //
                                                                                                     //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }    //
                                                                                                     //
(0, _publications2['default'])();                                                                    // 4
(0, _methods2['default'])();                                                                         // 5
///////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./lib/collections/categories.js");
require("./lib/collections/index.js");
require("./lib/collections/products.js");
require("./lib/collections/users.js");
require("./server/methods/categories.js");
require("./server/methods/index.js");
require("./server/methods/products.js");
require("./server/methods/users.js");
require("./server/publications/categories.js");
require("./server/publications/index.js");
require("./server/publications/products.js");
require("./server/publications/users.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
